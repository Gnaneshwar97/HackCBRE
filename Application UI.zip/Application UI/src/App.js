import logo from './logo.svg';
import './App.css';
import DropdownExample from './DropdownExample.js';
import 'semantic-ui-css/semantic.min.css';
import LoginPage from './LoginPage.js';


function App() {
  return (
    <div className="App">
     <LoginPage/>
    </div>
  );
}

export default App;
